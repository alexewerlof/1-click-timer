//called by background to update the counter value
function updateCounter () {
	document.getElementById( "minute-counter" ).innerHTML =  timer.mStr ;
	document.getElementById( "second-counter" ).innerHTML =  timer.sStr ;
	
	// update the #minute-selector
	var m = timer.m;
	for ( var j = 1; j <= 60; j++ ) {
		if ( j <= m ) {
			document.getElementById( "li-" + j ).classList.add( "included" );
		} else {
			document.getElementById( "li-" + j ).classList.remove( "included" );
		}
	}
}

//** updates the play button
function updatePlayButton () {
	if ( timer.isCounting() ) {
		document.getElementById( "stop" ).classList.remove( "play" );
	} else {
		document.getElementById( "stop" ).classList.add( "play" );
	}
}

//** updates the mute button
function updateMuteButton () {
	if ( timer.isMute() ) {
		document.getElementById( "sound" ).classList.add( "off" );
	} else {
		document.getElementById( "sound" ).classList.remove( "off" );
	}
}

//** changes the value of the counter with an offset
function changeCounter ( offset ) {
	timer.setTimerOffset( offset );
	updateCounter();
}

//** toggles stop status
function toggleStop() {
	if ( timer.isCounting() ) {
		timer.stop();
	} else {
		timer.start();
	}
	updatePlayButton();
}

//** toggles sound
function toggleSound() {
	timer.setMute( !timer.isMute() );
	updateMuteButton();
}

//this code runs when the popup window just opens
var minuteSelector = document.getElementById( "minute-selector" );
for ( var i = 60; i >= 1; i-- ) {
	var li = document.createElement( "li" );
	li.id = "li-" + i;
	li.innerHTML = '<span class= "minute-number">' + i + '</span>';
	(function ( i ) {
		li.onclick = function () {
			timer.setTimer( i * 60 );
			timer.start();
			updateCounter();
		}
	})( i, li );
	if ( i % 10 == 0 ) {
		li.classList.add( "tio" );
	}else if ( i % 5 == 0 ) {
		li.classList.add( "fem" );
	}
	minuteSelector.appendChild( li );
}

var timer = chrome.extension.getBackgroundPage().timer;
updateCounter();
updateMuteButton();
updatePlayButton();