var minuteSelector = document.getElementById( "minute-selector" );
for ( var i = 1; i<=60; i++ ) {
	var li = document.createElement( "li" );
	li.id = "li-" + i;
	(function(){
		var minutes = i;
		li.onclick = function() {
			localStorage[ "remainingTime" ] = minutes * 60;
			console.log( "Setting alarm to: " + minutes * 60 );
			updateCounter();
		}
	})();
	minuteSelector.appendChild( li );
}

function setAlarm ( sec ) {
	localStorage[ "remainingTime" ] = sec;
	window.close();
}

//called by background to update the counter value
function updateCounter () {
	var t = localStorage[ "remainingTime" ];
	var m = Math.floor( t / 60 );
	if ( m < 10 ) {
		m = "0" + m ;
	}
	var s = t % 60;
	if ( s < 10 ) {
		s = "0" + s ;
	}
	document.getElementById("minute-counter").innerHTML =  m ;
	document.getElementById("second-counter").innerHTML =  s ;
}

//changes the value of the counter with an offset
function changeCounter ( offset ) {
	var currentCounter = localStorage[ "remainingTime" ];
	var desiredCounter = parseInt( currentCounter ) + parseInt( offset );
	if ( desiredCounter <= 3600 && desiredCounter >= 0) {
		console.log( "Changing counter to: " + desiredCounter );
		localStorage[ "remainingTime" ] = desiredCounter;
		updateCounter();
	}
}

updateCounter();