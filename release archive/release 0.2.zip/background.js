//the very first initial value
localStorage[ "remainingTime" ] = 0;


var lastNotification = null;

// Run this every second
function intervalFn() {
	var remainingTime = localStorage[ "remainingTime" ];
	if ( !remainingTime || remainingTime == 0 ) {
		return;
	} else if( remainingTime < 0 ) {
		//minus value means that the alarm is stopped
		console.log( "Alarm is stopped with value: " + remainingTime );
		return;
	} else {
		//ok, now we know remainingTime is > 0
		console.log( remainingTime + " sec remaining" );
		localStorage[ "remainingTime" ] = --remainingTime;
		var popup = chrome.extension.getViews( { type: "popup" } );
		if( popup.length == 1 ) {// popup is open
			popup[0].updateCounter();
		}
		if ( remainingTime == 0 ) {
			//if there's already a notification showing, hide it
			if ( lastNotification ) {
				lastNotification.cancel();
			}
			lastNotification = webkitNotifications.createHTMLNotification( 'notification.html' );
			lastNotification.show();
			console.log( "Notification shows!" );
		}
	}
}

setInterval( intervalFn, 1000 );