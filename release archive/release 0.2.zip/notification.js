//snoozes the alarm for the specified number of seconds
function snooze( sec ) {
	localStorage[ "remainingTime" ] = sec;
	window.close();
}