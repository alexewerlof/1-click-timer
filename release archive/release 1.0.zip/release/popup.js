//a flag that indicates that the mouse is hovering over #minute-selector
var minutesHovering = false;

var minuteSelector = document.getElementById( "minute-selector" );
for ( var i = 60; i >= 1; i-- ) {
	var li = document.createElement( "li" );
	li.id = "li-" + i;
	(function ( i ) {
		li.onclick = function() {
			localStorage[ "remainingTime" ] = i * 60;
			console.log( "Setting alarm to: " + i * 60 );
			updateCounter();
		}
		li.onmouseover = function(){
			for ( var j = 1; j <= 60; j++ ) {
				document.getElementById( "li-" + j ).className = j <= i ? "included": "";
			}
		};
	})( i );
	minuteSelector.appendChild( li );
}

function setAlarm ( sec ) {
	localStorage[ "remainingTime" ] = sec;
	window.close();
}

//called by background to update the counter value
function updateCounter () {
	var t = localStorage[ "remainingTime" ];
	var m = Math.floor( t / 60 );
	if ( m < 10 ) {
		m = "0" + m ;
	}
	var s = t % 60;
	if ( s < 10 ) {
		s = "0" + s ;
	}
	document.getElementById( "minute-counter" ).innerHTML =  m ;
	document.getElementById( "second-counter" ).innerHTML =  s ;
	
	if( !minutesHovering ) {
		for ( var j = 1; j <= 60; j++ ) {
			document.getElementById( "li-" + j ).className = j <= m ? "included": "";
		}
	}
}

//changes the value of the counter with an offset
function changeCounter ( offset ) {
	var currentCounter = localStorage[ "remainingTime" ];
	var desiredCounter = parseInt( currentCounter ) + parseInt( offset );
	if ( desiredCounter <= 3600 && desiredCounter >= 0) {
		console.log( "Changing counter to: " + desiredCounter );
		localStorage[ "remainingTime" ] = desiredCounter;
		updateCounter();
	}
}

//toggles stop status
function toggleStop() {
	var currentCounter = localStorage[ "remainingTime" ];
	var nextCounter = - parseInt( currentCounter );
	localStorage[ "remainingTime" ] = nextCounter;
	if ( nextCounter < 0 ) {
		document.getElementById( "stop" ).classList.add( "play" );
	} else {
		document.getElementById( "stop" ).classList.remove( "play" );
	}
}

//toggles sound
function toggleSound() {
	if ( localStorage[ "sound" ] === "true" ) {
		localStorage[ "sound" ] = "false";
		document.getElementById( "sound" ).classList.add( "off" );
	} else {
		localStorage[ "sound" ] = "true";
		document.getElementById( "sound" ).classList.remove( "off" );
	}
}

updateCounter();