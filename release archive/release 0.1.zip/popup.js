/*
i=0;
setInterval(function(){console.log(++i);},500);
*/

function setAlarm ( sec ) {
	localStorage[ "remainingTime" ] = sec;
	window.close();
}

//called by background to update the counter value
function setCounter ( counter ) {
	counterDiv.innerHTML = counter;
}